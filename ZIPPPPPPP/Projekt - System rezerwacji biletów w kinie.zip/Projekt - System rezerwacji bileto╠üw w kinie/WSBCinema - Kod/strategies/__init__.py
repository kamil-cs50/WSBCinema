# Plik __init__.py w katalogu strategies
# Oznacza katalog strategies jako pakiet Python