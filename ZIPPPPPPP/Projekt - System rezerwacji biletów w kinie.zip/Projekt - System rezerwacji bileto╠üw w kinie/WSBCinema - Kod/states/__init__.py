# Plik __init__.py w katalogu states
# Oznacza katalog states jako pakiet Python