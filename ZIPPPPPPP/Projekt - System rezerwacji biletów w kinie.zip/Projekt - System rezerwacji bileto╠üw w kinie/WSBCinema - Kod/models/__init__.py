# Plik __init__.py w katalogu models
# Oznacza katalog models jako pakiet Python