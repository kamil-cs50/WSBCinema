# Plik __init__.py w katalogu views
# Oznacza katalog views jako pakiet Python