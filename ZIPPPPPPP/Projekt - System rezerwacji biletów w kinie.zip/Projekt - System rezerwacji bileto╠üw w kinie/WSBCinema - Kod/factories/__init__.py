# Plik __init__.py w katalogu factories
# Oznacza katalog factories jako pakiet Python