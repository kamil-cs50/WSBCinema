# Plik __init__.py w katalogu decorators
# Oznacza katalog decorators jako pakiet Python