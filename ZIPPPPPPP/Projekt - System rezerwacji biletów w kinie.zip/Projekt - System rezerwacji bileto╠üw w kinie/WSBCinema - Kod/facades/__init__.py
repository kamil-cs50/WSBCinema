# Plik __init__.py w katalogu facades
# Oznacza katalog facades jako pakiet Python