# Plik __init__.py w katalogu observers
# Oznacza katalog observers jako pakiet Python