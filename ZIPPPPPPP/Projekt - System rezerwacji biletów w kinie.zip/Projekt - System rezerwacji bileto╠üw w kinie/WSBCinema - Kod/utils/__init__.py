# Plik __init__.py w katalogu utils
# Oznacza katalog utils jako pakiet Python